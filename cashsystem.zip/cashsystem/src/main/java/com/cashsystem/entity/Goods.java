package com.cashsystem.entity;

import lombok.Data;


@Data
public class Goods {
    private Integer id;
    private String name;
    private String introduce;
    private Integer stock;
    private String unit;
    private Integer price;
    private Integer discount;
    private Integer buyGoodsNum;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("********商品信息***********").append("\n");
        sb.append("\t").append("【商品名称】：").append(this.getName()).append("\n");
        sb.append("\t").append("【商品简介】：").append(this.getIntroduce()).append("\n");
        sb.append("\t").append("【商品库存】：").append(this.getStock()).append("\n");
        sb.append("\t").append("【商品单位】：").append(this.getUnit()).append("\n");
        sb.append("\t").append("【商品价格】：").append(this.getPrice()).append("\n");
        sb.append("\t").append("【商品折扣】：").append(this.getDiscount()).append("\n");
        return sb.toString();
    }
}