package com.cashsystem.dao;

import com.cashsystem.common.AccountStatus;
import com.cashsystem.common.AccountType;
import com.cashsystem.entity.Account;
import com.cashsystem.entity.Goods;
import com.sun.xml.internal.bind.v2.runtime.reflect.Lister;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class GoodsDao extends BaseDao{
    public List<Goods> quarryAllGoods() {
        List<Goods> list = new ArrayList<>();
        Goods goods;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.getConnection(true);
            String sql = "select id,name,introduce,stock,price,discount from  goods ";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            //返回结果集到resultSet
            while (resultSet.next()){
                goods = extractGoods(resultSet);
                list.add(goods);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public boolean putAwayGoods(String name,String introduce,int stock,String unit,int price,int discount){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.getConnection(true);
            String sql = "insert into goods(name,introduce,stock,unit,price,discount) values(?,?,?,?,?,?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,name);
            preparedStatement.setString(2,introduce);
            preparedStatement.setInt(3,stock);
            preparedStatement.setString(4,unit);
            preparedStatement.setDouble(5,price);
            preparedStatement.setInt(6,discount);
            int a = preparedStatement.executeUpdate();
            if(a>0){
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  false;
    }

    public boolean goodsSoldOut(int id) {

        Connection connection;
        PreparedStatement preparedStatement;
        try {
            if(!judge(id)){
                System.out.println("商品信息输入有误");
                return false;
            }
            connection = this.getConnection(true);
            String sql = "delete from goods where id=? ";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,id);
            int a = preparedStatement.executeUpdate();
            if(a>0){
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  false;
    }
    private Goods extractGoods(ResultSet resultSet)throws Exception{
        Goods goods = new Goods();
        goods.setId(resultSet.getInt("id"));
        goods.setName(resultSet.getString("name"));
        goods.setIntroduce(resultSet.getString("introduce"));
        goods.setStock(resultSet.getInt("stock"));
        goods.setPrice(resultSet.getInt("price"));
        goods.setDiscount(resultSet.getInt("discount"));
        return goods;
    }
    private boolean judge(int id){
        Connection connection;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet;
        ArrayList<Integer> arrayList = new ArrayList<>();
        try {
            connection = this.getConnection(true);
            String sql = "select id from goods";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                arrayList.add(resultSet.getInt("id"));
            }
            for (Integer a : arrayList) {
                if (a == id) {
                    return true;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean goodsUpdate(int id,int goodStock,int price,int discount) {
        Connection connection = null;
        PreparedStatement preparedStatement;
        String sql="update goods set stock=?,price=?,discount=? where id=?";
        try {
            connection = this.getConnection(true);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,goodStock);
            preparedStatement.setInt(2,price);
            preparedStatement.setInt(3,discount);
            preparedStatement.setInt(4,id);
            int a = preparedStatement.executeUpdate();
            if(a>0){
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public void goodsBrowse(int goodsid) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.getConnection(true);
            String sql = "select id,name,introduce,stock,price,discount from  goods where id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,goodsid);
            resultSet = preparedStatement.executeQuery();
            //返回结果集到resultSet
            System.out.println("【商品信息】");
            while (resultSet.next()){
                int id1 = resultSet.getInt("id");
                System.out.println("【商品编号】"+id1);
                String name = resultSet.getString("name");
                System.out.println("【商品名称】"+name);
                String introduce = resultSet.getString("introduce");
                System.out.println("【商品简介】"+introduce);
                int stock = resultSet.getInt("stock");
                System.out.println("【商品库存】"+stock);
                int price = resultSet.getInt("price");
                System.out.println("【商品价格】"+1.00D*price/100);
                int discount = resultSet.getInt("discount");
                System.out.println("【商品折扣】"+discount);
                System.out.println("==================================");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public Goods getGoods(int id) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Goods goods = new Goods();
        try {
            connection = this.getConnection(true);
            String sql = "select * from  goods where id=? ";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                goods.setId(id);
                goods.setName(resultSet.getString("name"));
                goods.setIntroduce(resultSet.getString("introduce"));
                goods.setStock(resultSet.getInt("stock"));
                goods.setUnit(resultSet.getString("unit"));
                goods.setPrice(resultSet.getInt("price"));
                goods.setDiscount(resultSet.getInt("discount"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return goods;
    }
    public boolean updateAfterPay(Goods goods,int goodsBuyNum){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = this.getConnection(true);
            String sql = "update goods set stock=? where id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,goods.getStock()-goodsBuyNum);
            preparedStatement.setInt(2,goods.getId());

            if(preparedStatement.executeUpdate()==1){
                return true;
            }



        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
