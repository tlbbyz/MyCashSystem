package com.cashsystem.dao;

import com.cashsystem.common.OrderStatus;
import com.cashsystem.entity.Account;
import com.cashsystem.entity.Order;
import com.cashsystem.entity.Order_item;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class OrderDao extends BaseDao {



    public boolean commitOrder(Order order) {

        Connection connection=null;
        PreparedStatement preparedStatement = null;
        String insertOrderSql = "insert into `order`" +
                "(id, account_id, create_time, finish_time, " +
                "actual_amount, total_money, order_status, " +
                "account_name) values (?,?,now(),now(),?,?,?,?)";
        String insertOrderItemSql = "insert into order_item(order_id, goods_id, goods_name," +
                "goods_introduce, goods_num, goods_unit, goods_price, goods_discount) values (?,?,?,?,?,?,?,?)";
        try {
            connection=this.getConnection(false);

            preparedStatement = connection.prepareStatement(insertOrderSql);
            preparedStatement.setString(1,order.getId());
            preparedStatement.setInt(2,order.getAccount_id());
            preparedStatement.setInt(3,order.getActual_amount());
            preparedStatement.setInt(4,order.getTotal_money());
            preparedStatement.setInt(5,order.getOrder_status().getFlg());
            preparedStatement.setString(6,order.getAccount_name());
            //更新数据库
            if(preparedStatement.executeUpdate()==0){
                throw new RuntimeException("插入订单失败");
            }

            //插入订单项
            preparedStatement = connection.prepareStatement(insertOrderItemSql);
            for (Order_item order_item :order.getOrder_itemList()) {
                preparedStatement.setString(1,order_item.getOrder_id());
                preparedStatement.setInt(2,order_item.getGoods_id());
                preparedStatement.setString(3,order_item.getGoods_name());
                preparedStatement.setString(4,order_item.getGoods_introduce());
                preparedStatement.setInt(5,order_item.getGoods_num());
                preparedStatement.setString(6,order_item.getGoods_unit());
                preparedStatement.setInt(7,order_item.getGoods_price());
                preparedStatement.setInt(8,order_item.getGoods_discount());
                //将每一项preparedStatement 缓存好
                preparedStatement.addBatch();
            }
            //批量操作数据库
            int[]effects = preparedStatement.executeBatch();
            for (int a : effects) {
                if(a==0){
                    throw new RuntimeException("插入订单项失败");
                }
            }
            connection.commit();
        } catch (Exception e) {
            e.printStackTrace();
            if(connection!=null){
                try {
                    //回滚
                    connection.rollback();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            return false;
        }finally {
            this.closeResource(null,preparedStatement,connection);
        }
        return true;
    }

    //查询订单
    public List<Order> queryOrderByAccount(Account account) {
        List<Order> orderList = new ArrayList<>();
        List<Order_item> order_itemList = new ArrayList<>();
        Connection connection=null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Order order = null;
        try {
            connection = this.getConnection(false);
            String sql = "select `order`.* ,order_item.id as order_itemid,order_item.order_id, order_item.goods_id, order_item.goods_name," +
                    "order_item.goods_introduce,order_item.goods_num,order_item.goods_unit,order_item.goods_price," +
                    "order_item.goods_discount" +
                    " from `order` left join order_item on `order`.id= order_item.order_id where " +
                    "`order`.account_id = ?  order by order_id";

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,account.getId());

            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                if (order == null) {
                    order = new Order();
                    this.extractOrder(order, resultSet);
                    orderList.add(order);
                }
                String orderId = resultSet.getString("order_id");

                if (!orderId.equals(order.getId())) {
                    order = new Order();
                    this.extractOrder(order, resultSet);
                    orderList.add(order);
                    order_itemList = new ArrayList<>();

                }
                Order_item order_item = this.extractOrderItem(resultSet);
                order_itemList.add(order_item);
                order.setOrder_itemList(order_itemList);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderList;
    }

    private Order_item extractOrderItem(ResultSet resultSet) throws SQLException {
        Order_item orderItem = new Order_item();
        orderItem.setId(resultSet.getInt("order_itemid"));
        orderItem.setOrder_id(resultSet.getString("order_id"));
        orderItem.setGoods_id(resultSet.getInt("goods_id"));
        orderItem.setGoods_name(resultSet.getString("goods_name"));
        orderItem.setGoods_introduce(resultSet.getString("goods_introduce"));
        orderItem.setGoods_num(resultSet.getInt("goods_num"));
        orderItem.setGoods_unit(resultSet.getString("goods_unit"));
        orderItem.setGoods_price(resultSet.getInt("goods_price"));
        orderItem.setGoods_discount(resultSet.getInt("goods_discount"));
        return orderItem;

    }
    public void extractOrder(Order order,ResultSet resultSet) throws SQLException {
        order.setId(resultSet.getString("id"));
        order.setAccount_id(resultSet.getInt("account_id"));
        order.setAccount_name(resultSet.getString("account_name"));
        order.setCreate_time(resultSet.getTimestamp("create_time").toLocalDateTime());
        Timestamp finishTime = resultSet.getTimestamp("finish_time");
        if (finishTime != null) {
            order.setFinish_time(finishTime.toLocalDateTime());
        }
        order.setActual_amount(resultSet.getInt("actual_amount"));
        order.setTotal_money(resultSet.getInt("total_money"));
        order.setOrder_status(OrderStatus.valueOf(resultSet.getInt("order_status")));
    }
}
