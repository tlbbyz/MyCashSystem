package com.cashsystem.service;

import com.cashsystem.dao.AccountDao;
import com.cashsystem.dao.GoodsDao;
import com.cashsystem.entity.Account;
import com.cashsystem.entity.Goods;

import java.util.List;

public class GoodsService {
    private GoodsDao goodsDao;

    public GoodsService() {
        this.goodsDao = new GoodsDao();
    }


    public boolean goodsPutAway(String name,String introduce,int stock,String unit,int price,int discount) {
        return this.goodsDao.putAwayGoods(name,introduce,stock,unit,price,discount);
    }

    public boolean goodsSoldOut(int id) {
        return this.goodsDao.goodsSoldOut(id);
    }

    public boolean goodsUpdate(int id,int goodStock,int price,int discount) {
        return this.goodsDao.goodsUpdate(id,goodStock,price,discount);
    }
    public List<Goods> quarryAllGoods(){
        return this.goodsDao.quarryAllGoods();
    }
    //更新商品时查看商品信息
    public void goodsBrowse(int goodsid) {
        this.goodsDao.goodsBrowse(goodsid);
    }
    public boolean updateAfterPay(Goods goods, int goodsNum){
        return this.goodsDao.updateAfterPay(goods,goodsNum);
    }

    public Goods getGoods(int goodsid) {
        return this.goodsDao.getGoods(goodsid);
    }
}
