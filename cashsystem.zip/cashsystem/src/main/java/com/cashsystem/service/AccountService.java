package com.cashsystem.service;

import com.cashsystem.dao.AccountDao;
import com.cashsystem.entity.Account;

import java.util.List;

public class AccountService {
    private AccountDao accountDao;

    public AccountService() {
        this.accountDao = new AccountDao();
    }
    public Account login(String username,String password){
        return  this.accountDao.login(username,password);
    }


    public boolean register(Account account) {
        return this.accountDao.register(account);
    }

    public boolean accountStatusSet(int status,int id) {
        return this.accountDao.accountStatusSet(status,id);
    }

    public void printfAccount(int id) {
        this.accountDao.printfAccount(id);
    }

    public boolean accountPasswordReset(int id,String password) {
        return this.accountDao.accountPasswordReset(id,password);
    }

    public List<Account> lookUsers() {
        return this.accountDao.lookUsers();
    }
}
