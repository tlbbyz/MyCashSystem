package com.cashsystem.cmd.impl.order;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.CommandMeta;
import com.cashsystem.cmd.annotation.CustomerCommand;
import com.cashsystem.common.OrderStatus;
import com.cashsystem.entity.Goods;
import com.cashsystem.entity.Order;
import com.cashsystem.entity.Order_item;

import java.time.LocalDateTime;
import java.util.*;

@CommandMeta(
        name = "ZF",
        desc = "支付订单",
        group = "订单信息"
)
@CustomerCommand
public class OrderPayCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        System.out.println("请输入你要购买的商品编号与数量用，分隔： 如1-2，4-2");
        String goodsStr = scanner.nextLine();
        String[] str = goodsStr.split(",");
        List<Order_item> order_itemList = new ArrayList<>();
        List<Goods> goodsList = new ArrayList<>();
        Order order = new Order();
        int total = 0;
        int actual = 0;
        for (String string : str) {
            String[] str1 = string.split("-");
            int goodsid = Integer.parseInt(str1[0]);
            int goodsNum = Integer.parseInt(str1[1]);
            Goods goods = this.goodsService.getGoods(goodsid);
            goods.setBuyGoodsNum(goodsNum);
            goodsList.add(goods);
            total = total + goodsNum * goods.getPrice();
            actual = actual + goodsNum * goods.getPrice() * goods.getDiscount() / 100;
        }
        order.setId(String.valueOf(System.currentTimeMillis()));
        order.setAccount_id(subject.getAccount().getId());
        order.setAccount_name(subject.getAccount().getName());
        order.setCreate_time(LocalDateTime.now());
        order.setActual_amount(actual);
        order.setTotal_money(total);
        order.setOrder_status(OrderStatus.PLAYING);
        for (Goods goods : goodsList) {
            Order_item order_item = new Order_item();
            order_item.setOrder_id(order.getId());
            order_item.setGoods_id(goods.getId());
            order_item.setGoods_name(goods.getName());
            order_item.setGoods_introduce(goods.getIntroduce());
            order_item.setGoods_num(goods.getBuyGoodsNum());
            order_item.setGoods_unit(goods.getUnit());
            order_item.setGoods_price(goods.getPrice());
            order_item.setGoods_discount(goods.getDiscount());
            order_itemList.add(order_item);
            System.out.println(order_item.getGoods_num());
        }
        order.setOrder_itemList(order_itemList);

        System.out.println(order);

        System.out.println("以上为订单信息，请支付输入:zf");
        String result = scanner.nextLine();

        if ("zf".equalsIgnoreCase(result)) {
            order.setFinish_time(LocalDateTime.now());
            order.setOrder_status(OrderStatus.OK);
            boolean a = this.orderService.commitOrder(order);
            if (a) {
                for(Goods goods: goodsList){
                    boolean isUpdate = this.goodsService.updateAfterPay(goods,goods.getBuyGoodsNum());
                    if(isUpdate){
                        System.out.println("库存更新成功");
                    }else {
                        System.out.println("库存更新失败");
                    }
                }
                System.out.println("支付成功");

            }
        }
    }
}
