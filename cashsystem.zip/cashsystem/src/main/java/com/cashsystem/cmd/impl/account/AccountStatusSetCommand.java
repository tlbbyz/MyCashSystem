package com.cashsystem.cmd.impl.account;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.AdminCommand;
import com.cashsystem.cmd.annotation.CommandMeta;

@CommandMeta(
        name = "QTZH",
        desc = "启停账号",
        group = "账号信息"
)
@AdminCommand
public class AccountStatusSetCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        System.out.println("输入要修改的账号的ID：");
        int id = scanner.nextInt();
        this.accountService.printfAccount(id);
        System.out.println("请输入要修改的状态：1.启用  2.冻结");
        int status = scanner.nextInt();
        boolean a = this.accountService.accountStatusSet(status,id);
        if(a){
            System.out.println("修改成功");
        }else {
            System.out.println("修改失败");
        }
    }
}
