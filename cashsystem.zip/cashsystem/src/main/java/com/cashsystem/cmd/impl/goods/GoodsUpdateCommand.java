package com.cashsystem.cmd.impl.goods;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.AdminCommand;
import com.cashsystem.cmd.annotation.CommandMeta;

@CommandMeta(
        name = "GXSP",
        desc = "更新商品",
        group = "商品信息"
)
@AdminCommand
public class GoodsUpdateCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        System.out.println("请输入你要修改的商品的编号：");
        int id = scanner.nextInt();
        System.out.println("商品信息");
        goodsService.goodsBrowse(id);
        System.out.println("将商品的数量修改为:");
        int goodsStock = scanner.nextInt();
        System.out.println("将该商品的价格修改为(单位:分):");
        int price = scanner.nextInt();
        System.out.println("将该商品的折扣修改为：75代表75折");
        int discount = scanner.nextInt();
        boolean result = this.goodsService.goodsUpdate(id,goodsStock,price,discount);
        if(result){
            System.out.println("商品更新成功");
        }else {
            System.out.println("商品更新失败");
        }
    }
}
