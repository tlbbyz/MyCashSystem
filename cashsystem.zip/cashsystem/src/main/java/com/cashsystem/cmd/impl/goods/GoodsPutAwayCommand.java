package com.cashsystem.cmd.impl.goods;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.AdminCommand;
import com.cashsystem.cmd.annotation.CommandMeta;

@CommandMeta(
        name = "SJSP",
        desc = "上架商品",
        group = "商品信息"
)
@AdminCommand
public class GoodsPutAwayCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        System.out.println("输入商品名称");
        String name = scanner.nextLine();
        System.out.println("输入商品简介");
        String introduce = scanner.nextLine();
        System.out.println("输入商品库存");
        int stock = Integer.valueOf(scanner.nextLine());
        System.out.println("输入库存单位:箱、个、包......");
        String unit = scanner.nextLine();
        System.out.println("输入商品价格(单位：元）：");
        int price = Integer.valueOf(scanner.nextLine())*100;
        System.out.println("输入商品折扣（0-100）");
        int discount = Integer.valueOf(scanner.nextLine());

        // goodsPutAway(Goods goods)
        boolean result = this.goodsService.goodsPutAway(name,introduce,stock,unit,price,discount);
        if(result){
            System.out.println("商品上架成功");
        }else {
            System.out.println("商品上架失败");
        }
    }
}
