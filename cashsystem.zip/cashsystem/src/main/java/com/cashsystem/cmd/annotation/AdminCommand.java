package com.cashsystem.cmd.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
//源注解   运行的时候注解不仅被保存到class文件中，jvm加载class文件之后仍然存在

/**
 * @ Retention(RetentionPolicy.RUNTIME)
 * 运行的时候注解不仅被保存到class文件中，jvm加载class文件之后仍然存在
 * @ Target(ElementType.TYPE)说明了Annotation所修饰的对象范围：
 * 只会注解到类上面，用于反射取得class对象
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface AdminCommand {

}
