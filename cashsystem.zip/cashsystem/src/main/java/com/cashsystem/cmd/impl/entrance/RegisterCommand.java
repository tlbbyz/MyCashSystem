package com.cashsystem.cmd.impl.entrance;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.CommandMeta;
import com.cashsystem.cmd.annotation.EntranceCommand;
import com.cashsystem.common.AccountStatus;
import com.cashsystem.common.AccountType;
import com.cashsystem.entity.Account;
import org.apache.commons.codec.digest.DigestUtils;

@CommandMeta(
        name = "ZC",
        desc = "注册",
        group = "入口命令"
)
@EntranceCommand
public class RegisterCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        System.out.println("请输入用户名:");
        String username = scanner.nextLine();
        System.out.println("请输入密码：");
        String password = scanner.nextLine();
        System.out.println("请再次输入密码");
        String password1 = scanner .nextLine();
        if(!password.equals(password1)){
            System.out.println("两次输入不一致");
            return;
        }
        System.out.println("请输入姓名:");
        String name = scanner.nextLine();
        System.out.println("请输入账户类型:1.管理员 2.用户");
        int accountType = scanner.nextInt();
        AccountType accountType1 = AccountType.valueOf(accountType);
        System.out.println("请输入账户状态:1.启用 2.冻结");
        int accountStatus = scanner.nextInt();
        AccountStatus accountStatus1 = AccountStatus.valueOf(accountStatus);
        final Account account = new Account();
        account.setUsername(username);
        account.setPassword(DigestUtils.md5Hex(password1));
        account.setName(name);
        account.setAccountType(accountType1);
        account.setAccountStatus(accountStatus1);
        boolean result = this.accountService.register(account);
        if(result){
            System.out.println("注册成功");
        }else {
            System.out.println("注册失败");
        }
    }
}
