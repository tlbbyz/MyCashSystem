package com.cashsystem.cmd.impl.account;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.AdminCommand;
import com.cashsystem.cmd.annotation.CommandMeta;
import com.cashsystem.entity.Account;

import java.util.List;

@CommandMeta(
        name="CKZH",
        desc = "查看账户",
        group = "账号信息"
)
@AdminCommand
public class AccountBrowseCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        List<Account> list = this.accountService.lookUsers();
        for (Account a :list) {
            System.out.print("   账号编号   :");
            System.out.println(a.getId());
            System.out.print("     账号     :");
            System.out.println(a.getUsername());
            System.out.print("   账号类型   :");
            System.out.println(a.getAccountType());
            System.out.print("   账号状态   :");
            System.out.println(a.getAccountStatus());
            System.out.println("**********分割线***********");
        }
    }
}
