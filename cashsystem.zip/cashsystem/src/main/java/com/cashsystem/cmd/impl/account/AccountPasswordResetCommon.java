package com.cashsystem.cmd.impl.account;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.AdminCommand;
import com.cashsystem.cmd.annotation.CommandMeta;

@CommandMeta(
        name = "MMCZ",
        desc = "重置密码",
        group = "账号信息"
)
@AdminCommand
public class AccountPasswordResetCommon extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        System.out.println("请输入要修改的用户id：");
        int id = Integer.parseInt(scanner.nextLine());
        this.accountService.printfAccount(id);
        String password1;String password;
        while (true) {
            System.out.println("请输入新密码：");
            password = scanner.nextLine();
            System.out.println("请再次输入新密码");
            password1 = scanner.nextLine();
            if (!password.equals(password1)) {
                System.out.println("两次输入不一致请重新输出");
            }else {
                break;
            }
        }
        boolean a = this.accountService.accountPasswordReset(id,password1);
        if(a){
            System.out.println("密码修改成功");
        }else {
            System.out.println("密码修改失败");
        }
    }
}
