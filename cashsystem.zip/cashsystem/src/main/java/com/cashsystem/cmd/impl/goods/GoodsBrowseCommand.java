package com.cashsystem.cmd.impl.goods;

import com.cashsystem.cmd.impl.AbstractCommand;
import com.cashsystem.cmd.Subject;
import com.cashsystem.cmd.annotation.AdminCommand;
import com.cashsystem.cmd.annotation.CommandMeta;
import com.cashsystem.cmd.annotation.CustomerCommand;
import com.cashsystem.entity.Account;
import com.cashsystem.entity.Goods;

import java.util.List;

@CommandMeta(
        name = "LLSP",
        desc = "浏览商品",
        group = "商品信息"
)
@AdminCommand
@CustomerCommand
public class GoodsBrowseCommand extends AbstractCommand {
    @Override
    public void execute(Subject subject) {
        List<Goods> list  = this.goodsService.quarryAllGoods();
        System.out.println("【商品信息】");
        for (Goods goods:list) {
                System.out.println("【商品编号】"+goods.getId());
                System.out.println("【商品名称】"+goods.getName());
                System.out.println("【商品简介】"+goods.getIntroduce());
                System.out.println("【商品库存】"+goods.getStock());
                System.out.println("【商品价格】"+1.00D*goods.getPrice()/100);
                System.out.println("【商品折扣】"+1.00D*goods.getDiscount()/100);
                System.out.println("==================================");
        }

    }
}
